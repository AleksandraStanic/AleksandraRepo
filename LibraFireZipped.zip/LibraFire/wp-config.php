<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the installation.
 * You don't have to use the web site, you can copy this file to "wp-config.php"
 * and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://wordpress.org/support/article/editing-wp-config-php/
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'librafire' );

/** MySQL database username */
define( 'DB_USER', 'root' );

/** MySQL database password */
define( 'DB_PASSWORD', '' );

/** MySQL hostname */
define( 'DB_HOST', 'localhost' );

/** Database charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8mb4' );

/** The database collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication unique keys and salts.
 *
 * Change these to different unique phrases! You can generate these using
 * the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}.
 *
 * You can change these at any point in time to invalidate all existing cookies.
 * This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         'g8<8)JmlQ [T/o;Ph!k**<Unm}Gz/]<Jcvv}Kn!e^9$E6YgJ5{u~~pqhWZHX4;Af' );
define( 'SECURE_AUTH_KEY',  '7C!5yhfGa|T#.6!RW6-.n!AGHK*9Xt[:w=Xz<!Xvkbp8hl8p;Q;$w`!(rvDwb]o$' );
define( 'LOGGED_IN_KEY',    'bfW%#8u$Dw)82,eQvhw]iQgcrC_2RTOXsyV|ssJ.Hd[]QjA|!Frz2`RqihpU,Pvs' );
define( 'NONCE_KEY',        'K?yQrkQ:um?|kfM>Z>Hq&l*_ho[x<7XIVy>ak&P_!aBkp(GH/6TSjft^]FX]<H-d' );
define( 'AUTH_SALT',        'y 77OrqX9`bH]8?QwCAh!4_?Mi^/R8A^4=F4,$d!yWn!DvJGvk(2Pe.E t80Icqj' );
define( 'SECURE_AUTH_SALT', 'CLs=2ejm}RH+vF{{f/O>~{V9*`DhO1[D8vP`mLIac#0T xWaZM6P6#D]V?Rl&8:T' );
define( 'LOGGED_IN_SALT',   '9O+%vvQ)`:Z$Z{gAyEQ,O.IeC>,1/<ot]<m^Yf*%eL;.lQ9`w8``>>9T`^oYdsZV' );
define( 'NONCE_SALT',       'gS!0vm63* 4$a@lzS7hX/:k)6GZ3#|(S9[C(1O?8QrAl-&mO:iM4_V&G@4?c5!,:' );

/**#@-*/

/**
 * WordPress database table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the documentation.
 *
 * @link https://wordpress.org/support/article/debugging-in-wordpress/
 */
define( 'WP_DEBUG', false );

/* Add any custom values between this line and the "stop editing" line. */



/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
